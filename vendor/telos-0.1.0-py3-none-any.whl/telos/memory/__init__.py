"""memory/ — cross-session knowledge base (TELOS-internal; not host-injected).

The ``Memory`` protocol is defined in ``core/interfaces.py``. This module
re-exports it for convenience and provides the ``NullMemory`` default used
until the concrete store is built (ADR-0005).
"""

from telos.core.interfaces import Memory, PlanningContext

__all__ = ["Memory", "NullMemory"]


class NullMemory:
    """No-op ``Memory`` implementation used as the default until the store is built.

    ``recall`` always returns an empty string, so the planner receives no
    cross-session knowledge — safe and correct when there is no knowledge base.
    """

    def recall(self, ctx: PlanningContext) -> str:
        """Return empty string — no cross-session knowledge available."""
        return ""
