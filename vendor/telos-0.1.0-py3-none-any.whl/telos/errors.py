"""TELOS boundary error types.

All errors raised at the public boundary are subclasses of TelosError.
Plan state is left intact whenever a TelosError is raised, so the host
may safely retry the same call.
"""


class TelosError(Exception):
    """Base for all TELOS boundary errors. Plan state is left intact when raised."""


class PlannerError(TelosError):
    """The planner LLM was unreachable or returned something unusable/unparseable.

    The host MAY retry the same call; TELOS does not retry on its own.
    """


class UsageError(TelosError):
    """step() was called after the session already reached a terminal outcome
    (GOAL_REACHED / HORIZON_REACHED / FAILED). TELOS records the outcome and
    rejects any further call.
    """
