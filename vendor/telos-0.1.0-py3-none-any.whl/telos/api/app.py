"""FastAPI application: POST /v1/step and GET /healthz.

One request = one ``Telos`` instance.  The service stores nothing between
requests; the caller carries the ``ContinuationState`` and passes it back on
the next call to continue a session.

The ``PlannerLLM`` is built once at process startup via the FastAPI lifespan
and stored in ``app.state.planner_llm``; it is injected per-request through
the ``get_planner_llm`` dependency so tests can override it without env vars.

Error mapping (api-spec.md §7 / technical-spec.md §11.5):

    Library cause                   HTTP    error.type
    ─────────────────────────────── ─────── ──────────────────
    terminal Result (200 = outcome) 200     —
    ValueError / invariant breach   400     validation_error
    Pydantic body parse failure     422     schema_error  (RequestValidationError)
    UsageError (terminal re-sent)   409     usage_error
    PlannerError                    502     planner_error
    unexpected                      500     internal_error
"""

from __future__ import annotations

import logging
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from typing import Annotated, cast

from fastapi import Depends, FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from telos import PlannerLLM
from telos.api.config import build_planner_llm
from telos.api.schemas import (
    ActionModel,
    ActionOutcome,
    ContinuationState,
    StatusStr,
    StepRequest,
    StepResponse,
    TerminalModel,
    TerminalOutcome,
)
from telos.api.serialization import continuation_to_session_state, session_state_to_continuation
from telos.errors import PlannerError, UsageError
from telos.facade import ActionNode, Result, Telos

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Lifespan — build the PlannerLLM once at startup
# ---------------------------------------------------------------------------


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Build the server-side PlannerLLM at startup; fail fast if misconfigured."""
    app.state.planner_llm = build_planner_llm()
    yield


app = FastAPI(title="TELOS", version="1.0.0", lifespan=lifespan)


# ---------------------------------------------------------------------------
# Dependency — injectable so tests can override without env vars
# ---------------------------------------------------------------------------


def get_planner_llm(request: Request) -> PlannerLLM:
    """Return the process-scoped PlannerLLM from app state."""
    return request.app.state.planner_llm  # type: ignore[no-any-return]


PlannerLLMDep = Annotated[PlannerLLM, Depends(get_planner_llm)]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _error(status: int, error_type: str, message: str) -> JSONResponse:
    return JSONResponse(
        status_code=status,
        content={"error": {"type": error_type, "message": message}},
    )


def _build_outcome(result: ActionNode | Result) -> ActionOutcome | TerminalOutcome:
    if isinstance(result, ActionNode):
        return ActionOutcome(
            kind="action",
            action=ActionModel(
                id=result.id,
                description=result.description,
                parent=result.parent,
            ),
        )
    return TerminalOutcome(
        kind="terminal",
        result=TerminalModel(status=cast(StatusStr, result.status.name)),
    )


# ---------------------------------------------------------------------------
# Exception handlers — uniform {"error": {type, message}} for all failures
# ---------------------------------------------------------------------------


def _format_validation_errors(exc: RequestValidationError) -> str:
    """Produce a client-safe error string from a RequestValidationError.

    Formats field locations and messages without leaking raw input values
    or server-internal details (``str(exc)`` embeds the full input dict).
    """
    parts: list[str] = []
    for e in exc.errors():
        loc = " → ".join(str(x) for x in e["loc"]) if e["loc"] else "body"
        parts.append(f"{loc}: {e['msg']}")
    return "; ".join(parts) if parts else "Request body failed schema validation."


@app.exception_handler(RequestValidationError)
async def _schema_error_handler(request: Request, exc: RequestValidationError) -> JSONResponse:
    return _error(422, "schema_error", _format_validation_errors(exc))


@app.exception_handler(StarletteHTTPException)
async def _http_exception_handler(request: Request, exc: StarletteHTTPException) -> JSONResponse:
    """Return a uniform error envelope for 404 / 405 and any other HTTP exceptions.

    Must register against ``starlette.exceptions.HTTPException`` (not
    ``fastapi.HTTPException``) because that is what Starlette's router raises
    internally for unmatched routes and wrong methods.
    """
    _type_map = {404: "not_found", 405: "method_not_allowed"}
    error_type = _type_map.get(exc.status_code, "http_error")
    return _error(exc.status_code, error_type, str(exc.detail))


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@app.get("/healthz")
def healthz() -> dict[str, str]:
    """Health probe — returns ``{"status": "ok"}`` on a healthy server."""
    return {"status": "ok"}


@app.post("/v1/step", response_model=None)
def step(req: StepRequest, planner_llm: PlannerLLMDep) -> StepResponse | JSONResponse:
    """Advance a TELOS planning session by exactly one step.

    A fresh session is started when ``req.state`` is absent/``null``; an
    existing session is resumed when ``req.state`` carries a prior
    ``ContinuationState``.  The response always includes the updated
    ``state``; the caller passes it back unchanged on the next request.

    All library exceptions are caught here and mapped to the uniform HTTP
    error body ``{"error": {"type": ..., "message": ...}}``.
    """
    try:
        if req.state is not None:
            session_state = continuation_to_session_state(req.state)
            telos = Telos.from_state(
                planner_llm=planner_llm,
                horizon_T=req.horizon,
                goal=req.goal,
                action_set=req.action_set,
                state=session_state,
            )
        else:
            telos = Telos(
                planner_llm=planner_llm,
                horizon_T=req.horizon,
                goal=req.goal,
                action_set=req.action_set,
            )

        result = telos.step(req.observation)
        snap = telos.snapshot()
        state: ContinuationState = session_state_to_continuation(snap)

        return StepResponse(outcome=_build_outcome(result), state=state)

    except ValueError as exc:
        return _error(400, "validation_error", str(exc))
    except UsageError as exc:
        return _error(409, "usage_error", str(exc))
    except PlannerError as exc:
        # Log the full error (may contain provider URLs / model slugs / HTTP
        # error bodies from the LLM backend) but return only a generic message
        # to the client — echoing raw provider text is a hardening gap.
        logger.warning("PlannerError in POST /v1/step: %s", exc)
        return _error(
            502, "planner_error", "The planner LLM was unreachable or returned unusable output."
        )
    except Exception:
        logger.exception("Unhandled error in POST /v1/step")
        return _error(500, "internal_error", "An unexpected error occurred.")
