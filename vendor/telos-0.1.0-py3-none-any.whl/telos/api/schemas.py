"""Pydantic wire models for the TELOS stateless HTTP API.

Implements the request/response schema and the ``ContinuationState`` shape
specified in api-spec.md §§4–6.  Text-only: the ``images`` argument is not
exposed over HTTP (follow-up per ADR-0007).

Enum string fields (``NodeModel.type``, ``NodeModel.status``,
``StackFrameModel.state``, ``TerminalModel.status``) validate against the
§3.1 names and reject anything else with a ``ValidationError``.
"""

from __future__ import annotations

from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field

# ---------------------------------------------------------------------------
# Continuation-state sub-models (api-spec.md §6 / §6.1)
# ---------------------------------------------------------------------------

NodeTypeStr = Literal["UNKNOWN", "ACTION", "AND", "OR"]
NodeStatusStr = Literal[
    "UNVISITED",
    "VISITED",
    "SUCCESS",
    "RECOVERABLE",
    "NOT_RECOVERABLE",
    "EXHAUSTED",
    "DELETED",
]
StackStateStr = Literal["ENTERING", "EXITING", "FAILED"]
StatusStr = Literal["GOAL_REACHED", "HORIZON_REACHED", "FAILED"]


class NodeModel(BaseModel):
    """Wire representation of a single plan-tree node (api-spec.md §6.1)."""

    model_config = ConfigDict(extra="forbid")

    id: str
    type: NodeTypeStr
    status: NodeStatusStr
    description: str
    parent: str | None
    children: list[str]
    next_child_index: int


class TreeModel(BaseModel):
    """Wire representation of the plan tree (api-spec.md §6)."""

    model_config = ConfigDict(extra="forbid")

    root_id: str
    nodes: list[NodeModel]


class StackFrameModel(BaseModel):
    """One DFS-stack frame (api-spec.md §6 — ``stack`` array element)."""

    model_config = ConfigDict(extra="forbid")

    node_id: str
    state: StackStateStr


class InsightsModel(BaseModel):
    """Planner insights snapshot carried across requests (api-spec.md §6)."""

    model_config = ConfigDict(extra="forbid")

    constraints: str
    progress: str
    suggestion: str


class TerminalModel(BaseModel):
    """Terminal session outcome (api-spec.md §5.1 / §6)."""

    model_config = ConfigDict(extra="forbid")

    status: StatusStr


class ContinuationState(BaseModel):
    """Full externalized session state.

    Returned in every non-terminal response; passed back unchanged to continue
    a session.  ``step_count`` maps to the library's ``t`` (steps taken so far).

    The three session constants (``goal``, ``action_set``, ``horizon``) are
    stored here so the service can validate them on every resume and reject
    any request that tries to change them mid-session.
    """

    model_config = ConfigDict(extra="forbid")

    goal: str
    action_set: str
    horizon: int
    tree: TreeModel
    stack: list[StackFrameModel]
    history: list[str]
    step_count: int
    insights: InsightsModel | None
    pending: str | None
    terminal: TerminalModel | None


# ---------------------------------------------------------------------------
# Outcome — discriminated union on ``kind`` (api-spec.md §5.1)
# ---------------------------------------------------------------------------


class ActionModel(BaseModel):
    """Payload for an action outcome (api-spec.md §5.1)."""

    id: str
    description: str
    parent: str | None


class ActionOutcome(BaseModel):
    """Outcome carrying the next action to execute."""

    kind: Literal["action"]
    action: ActionModel


class TerminalOutcome(BaseModel):
    """Outcome indicating the session has ended."""

    kind: Literal["terminal"]
    result: TerminalModel


Outcome = Annotated[
    ActionOutcome | TerminalOutcome,
    Field(discriminator="kind"),
]

# ---------------------------------------------------------------------------
# Request / Response (api-spec.md §§4–5)
# ---------------------------------------------------------------------------


class StepRequest(BaseModel):
    """POST /v1/step request body (api-spec.md §4).

    ``state`` is absent/``null`` for a fresh session, or the ``ContinuationState``
    returned by the previous response to continue an existing one.
    Text-only: no ``images`` field (``extra="forbid"`` makes spurious keys a 422).
    """

    model_config = ConfigDict(extra="forbid")

    goal: str
    action_set: str
    horizon: int
    observation: str
    state: ContinuationState | None = None


class StepResponse(BaseModel):
    """POST /v1/step response body (api-spec.md §5).

    ``state`` is always present — callers pass it back on the next request.
    """

    outcome: Outcome
    state: ContinuationState


__all__ = [
    "ActionModel",
    "ActionOutcome",
    "ContinuationState",
    "InsightsModel",
    "NodeModel",
    "NodeStatusStr",
    "NodeTypeStr",
    "Outcome",
    "StackFrameModel",
    "StackStateStr",
    "StatusStr",
    "StepRequest",
    "StepResponse",
    "TerminalModel",
    "TerminalOutcome",
    "TreeModel",
]
