"""Server-side ``PlannerLLM`` construction from deployment environment variables.

The API service acts as a TELOS host: it supplies the LLM backend from its own
deployment config rather than accepting credentials from callers.  Clients
never send LLM-related fields.

The concrete adapter lives in ``telos.planner.openrouter``; this module is
responsible only for reading the required environment variables and wiring
them into an ``OpenRouterPlanner`` instance.
"""

from __future__ import annotations

import os

from telos.planner.openrouter import OpenRouterPlanner


def build_planner_llm() -> OpenRouterPlanner:
    """Construct the server-side ``PlannerLLM`` from environment variables.

    Reads:
        ``OPENROUTER_API_KEY`` — OpenRouter API key (required).
        ``OPENROUTER_MODEL``   — Model slug, e.g. ``"meta-llama/llama-3.3-70b-instruct:free"``
                                  (required).

    Raises:
        RuntimeError: If a required environment variable is missing.
    """
    api_key = os.environ.get("OPENROUTER_API_KEY")
    model = os.environ.get("OPENROUTER_MODEL")
    if not api_key:
        raise RuntimeError("OPENROUTER_API_KEY environment variable is not set")
    if not model:
        raise RuntimeError("OPENROUTER_MODEL environment variable is not set")
    return OpenRouterPlanner(api_key=api_key, model=model)
