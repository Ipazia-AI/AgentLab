"""SessionState ↔ ContinuationState bidirectional mapping.

Converts between the library's in-process ``SessionState`` (held by the Telos
facade after each ``step`` call) and the Pydantic ``ContinuationState`` that
travels on the wire.

Import discipline: this module imports only from ``telos.facade`` (the public
seam) and ``telos.core.model`` (for the ``Tree``/``Node`` serde methods added
alongside the seam).  It never imports from ``telos.core.engine`` or
``telos.core.interfaces``.
"""

from __future__ import annotations

from typing import cast

from telos.api.schemas import (
    ContinuationState,
    InsightsModel,
    NodeModel,
    StackFrameModel,
    StackStateStr,
    StatusStr,
    TerminalModel,
    TreeModel,
)
from telos.core.model import StackState, Tree
from telos.facade import Insights, Result, SessionState, Status


def session_state_to_continuation(state: SessionState) -> ContinuationState:
    """Dump a ``SessionState`` to a ``ContinuationState`` wire model.

    Uses ``Tree.to_dict`` / ``Node.to_dict`` to serialize the plan tree and
    converts each field to its Pydantic-validated wire representation.
    Enum values are carried as their §3.1 names (e.g. ``"ENTERING"``).
    """
    tree_dict = state.tree.to_dict()
    return ContinuationState(
        goal=state.goal,
        action_set=state.action_set,
        horizon=state.horizon_T,
        tree=TreeModel(
            root_id=tree_dict["root_id"],
            nodes=[
                NodeModel(
                    id=n["id"],
                    type=n["type"],
                    status=n["status"],
                    description=n["description"],
                    parent=n["parent"],
                    children=n["children"],
                    next_child_index=n["next_child_index"],
                )
                for n in tree_dict["nodes"]
            ],
        ),
        stack=[
            StackFrameModel(node_id=nid, state=cast(StackStateStr, ss.name))
            for nid, ss in state.stack
        ],
        history=list(state.history),
        step_count=state.t,
        insights=(
            InsightsModel(
                constraints=state.insights.constraints,
                progress=state.insights.progress,
                suggestion=state.insights.suggestion,
            )
            if state.insights is not None
            else None
        ),
        pending=state.pending,
        terminal=(
            TerminalModel(status=cast(StatusStr, state.terminal.status.name))
            if state.terminal is not None
            else None
        ),
    )


def continuation_to_session_state(cs: ContinuationState) -> SessionState:
    """Rebuild a ``SessionState`` from a ``ContinuationState`` wire model.

    Uses ``Tree.from_dict`` to reconstruct the plan tree (preserving child
    order and per-parent counters), and maps Pydantic-validated enum name
    strings back to the library enum members.
    """
    tree = Tree.from_dict(
        {
            "root_id": cs.tree.root_id,
            "nodes": [
                {
                    "id": n.id,
                    "type": n.type,
                    "status": n.status,
                    "description": n.description,
                    "parent": n.parent,
                    "children": list(n.children),
                    "next_child_index": n.next_child_index,
                }
                for n in cs.tree.nodes
            ],
        }
    )
    return SessionState(
        tree=tree,
        stack=[(f.node_id, StackState[f.state]) for f in cs.stack],
        history=list(cs.history),
        t=cs.step_count,
        insights=(
            Insights(
                constraints=cs.insights.constraints,
                progress=cs.insights.progress,
                suggestion=cs.insights.suggestion,
            )
            if cs.insights is not None
            else None
        ),
        pending=cs.pending,
        terminal=(Result(Status[cs.terminal.status]) if cs.terminal is not None else None),
        goal=cs.goal,
        action_set=cs.action_set,
        horizon_T=cs.horizon,
    )


__all__ = [
    "continuation_to_session_state",
    "session_state_to_continuation",
]
