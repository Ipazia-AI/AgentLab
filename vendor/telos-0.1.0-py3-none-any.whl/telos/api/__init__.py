"""TELOS stateless HTTP API surface.

Provides the Pydantic wire models (``schemas.py``), the
``SessionState`` ↔ ``ContinuationState`` mapping (``serialization.py``),
and the FastAPI endpoint (``app.py``).

The core library works without this package; the ``api`` optional-dependency
group (``pydantic``, ``fastapi``, ``httpx``) must be installed to import
from ``telos.api``.  Run ``make setup`` to install everything.
"""
