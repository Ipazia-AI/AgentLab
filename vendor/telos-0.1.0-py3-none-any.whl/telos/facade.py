"""Orchestration layer — the ``Telos`` facade and its public return types.

This is the thin dispatcher that:
- owns the session constants and mutable state (tree, stack, history, pending, …);
- wires ``core/`` (deterministic engine) with ``planner/`` (LLM-backed reasoning);
- exposes the single public method ``step(observation, *, images)``.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from enum import Enum, auto

from telos.core.engine import apply_prune_guard, get_action_node
from telos.core.interfaces import Image, Insights, Memory, Planner, PlannerLLM, PlanningContext
from telos.core.model import NodeId, NodeStatus, StackState, Tree
from telos.errors import UsageError
from telos.memory import NullMemory
from telos.planner.llm_planner import LLMPlanner

# ---------------------------------------------------------------------------
# Public return types
# ---------------------------------------------------------------------------


class Status(Enum):
    """Terminal outcome of a TELOS session.

    Every ``Status`` is terminal; a non-terminal step returns an ``ActionNode``.
    """

    GOAL_REACHED = auto()
    HORIZON_REACHED = auto()
    FAILED = auto()


@dataclass(frozen=True)
class Result:
    """Returned by ``step`` when the session has reached a terminal outcome."""

    status: Status


@dataclass(frozen=True)
class ActionNode:
    """Read-only projection of an internal ACTION node, handed to the host.

    Only ACTION nodes on the success path cross the public boundary.
    The host grounds and executes ``description`` in the environment, then
    calls ``step`` again with the resulting observation.
    """

    id: NodeId
    description: str  # NL target-state instruction the host grounds + executes
    parent: NodeId | None


# ---------------------------------------------------------------------------
# Session-state snapshot (serialization seam)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SessionState:
    """Serializable snapshot of the facade's held state.

    Carries both the mutable per-session working state (tree, stack, history,
    step counter, insights, pending action, terminal result) and the three
    session constants (goal, action_set, horizon_T).  Embedding the constants
    allows ``from_state`` to compare them against the re-supplied values and
    reject requests where they do not match — catching accidental mismatches
    such as a client that updated ``goal`` without starting a new session.

    ``planner_llm`` is still re-supplied at reconstruction time and is never
    serialized (credentials must not travel in the state blob).
    """

    tree: Tree
    stack: list[tuple[NodeId, StackState]]
    history: list[str]
    t: int
    insights: Insights | None
    pending: NodeId | None
    terminal: Result | None
    # Session constants — stored so from_state() can enforce equality on resume.
    goal: str
    action_set: str
    horizon_T: int


# ---------------------------------------------------------------------------
# Telos — the public API object
# ---------------------------------------------------------------------------


class Telos:
    """Stateful planning session. One instance = one session; not thread-safe.

    Session constants (``planner_llm``, ``goal``, ``action_set``, ``horizon_T``)
    are fixed at construction; thereafter one ``step`` call per environment step.

    ``planner`` and ``memory`` are injection seams for tests and future wiring;
    defaults are constructed here in orchestration, never inside ``core/``.
    """

    def __init__(
        self,
        planner_llm: PlannerLLM,
        horizon_T: int,
        goal: str,
        action_set: str,
        *,
        planner: Planner | None = None,
        memory: Memory | None = None,
    ) -> None:
        """Construct a new planning session.

        Args:
            planner_llm: Host-supplied LLM backend (provider, credentials, model).
            horizon_T: Maximum number of steps (must be > 0).
            goal: Plain-language task description; constant for the session.
            action_set: Host-provided text describing supported actions.
            planner: Optional injected ``Planner`` (defaults to ``LLMPlanner``).
            memory: Optional injected ``Memory`` (defaults to ``NullMemory``).

        Raises:
            ValueError: If ``horizon_T`` is not a positive integer.
        """
        if horizon_T <= 0:
            raise ValueError(f"horizon_T must be a positive integer, got {horizon_T!r}")

        self._goal = goal
        self._action_set = action_set
        self._T_max = horizon_T

        # Defaults constructed in orchestration, never inside core/.
        self._planner: Planner = planner if planner is not None else LLMPlanner(planner_llm)
        self._memory: Memory = memory if memory is not None else NullMemory()

        # Mutable session state (§6.1).
        self._tree = Tree(goal)
        self._stack: list[tuple[NodeId, StackState]] = [(self._tree.root_id, StackState.ENTERING)]
        self._history: list[str] = []
        self._t: int = 0
        self._insights: Insights | None = None
        self._pending: NodeId | None = None
        self._terminal: Result | None = None

    def step(
        self,
        observation: str,
        *,
        images: list[Image] | None = None,
    ) -> ActionNode | Result:
        """Advance the session by one environment step.

        Completes the pending step (if any) by verifying *observation* against
        it, then plans the next step and returns it as an ``ActionNode``.
        Returns a terminal ``Result`` when the session ends.

        Args:
            observation: Host-defined text snapshot of the current environment state.
            images: Optional screenshots passed as ``Image`` blocks; ``None`` for
                    text-only hosts.

        Returns:
            An ``ActionNode`` while a step is reachable, or a terminal ``Result``
            (``GOAL_REACHED`` / ``HORIZON_REACHED`` / ``FAILED``) when done.

        Raises:
            UsageError: If called after the session has already ended.
            PlannerError: If the LLM was unreachable or returned unusable output.
        """
        if self._terminal is not None:
            raise UsageError(
                "step() called after the session has already reached a terminal outcome"
            )
        if self._pending is not None:
            outcome = self._complete_pending(observation, images)
            if outcome is not None:
                return outcome
        return self._plan_next(observation, images)

    # ------------------------------------------------------------------
    # Serialization seam
    # ------------------------------------------------------------------

    def snapshot(self) -> SessionState:
        """Return a serializable snapshot of the current held state.

        Call after ``step`` returns to externalize the session for stateless
        transports. The snapshot shares the live ``Tree`` reference — callers
        must serialize it immediately rather than mutating the session after
        calling ``snapshot``.
        """
        return SessionState(
            tree=self._tree,
            stack=list(self._stack),
            history=list(self._history),
            t=self._t,
            insights=self._insights,
            pending=self._pending,
            terminal=self._terminal,
            goal=self._goal,
            action_set=self._action_set,
            horizon_T=self._T_max,
        )

    @classmethod
    def from_state(
        cls,
        planner_llm: PlannerLLM,
        horizon_T: int,
        goal: str,
        action_set: str,
        state: SessionState,
        *,
        planner: Planner | None = None,
        memory: Memory | None = None,
    ) -> Telos:
        """Rebuild a planning session from a prior serialized state.

        ``planner_llm`` must be re-supplied; it is never stored in the state
        blob because credentials must not travel in externalized session data.

        The three session constants (``goal``, ``action_set``, ``horizon_T``)
        are compared against the values embedded in ``state``.  A mismatch
        indicates an inconsistency between the request fields and the state
        blob — typically a client that changed a constant without starting a
        new session.

        Args:
            planner_llm: Host-supplied LLM backend.
            horizon_T: Maximum number of steps (must be > 0).
            goal: Plain-language task description; session constant.
            action_set: Host-provided text describing supported actions.
            state: Snapshot produced by ``snapshot()``.
            planner: Optional injected ``Planner`` (defaults to ``LLMPlanner``).
            memory: Optional injected ``Memory`` (defaults to ``NullMemory``).

        Raises:
            ValueError: If ``horizon_T`` is not a positive integer, or if any
                session constant does not match the value stored in ``state``.
        """
        if horizon_T <= 0:
            raise ValueError(f"horizon_T must be a positive integer, got {horizon_T!r}")
        if goal != state.goal:
            raise ValueError(f"goal mismatch on resume: got {goal!r}, expected {state.goal!r}")
        if action_set != state.action_set:
            raise ValueError(
                f"action_set mismatch on resume: got {action_set!r}, expected {state.action_set!r}"
            )
        if horizon_T != state.horizon_T:
            raise ValueError(
                f"horizon_T mismatch on resume: got {horizon_T!r}, expected {state.horizon_T!r}"
            )
        instance: Telos = cls.__new__(cls)
        instance._goal = goal
        instance._action_set = action_set
        instance._T_max = horizon_T
        instance._planner = planner if planner is not None else LLMPlanner(planner_llm)
        instance._memory = memory if memory is not None else NullMemory()
        instance._tree = state.tree
        instance._stack = list(state.stack)
        instance._history = list(state.history)
        instance._t = state.t
        instance._insights = state.insights
        instance._pending = state.pending
        instance._terminal = state.terminal
        return instance

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _make_ctx(
        self,
        observation: str,
        images: list[Image] | None,
        insights: Insights | None,
    ) -> PlanningContext:
        """Assemble a ``PlanningContext`` snapshot for the current call.

        Renders ``tree_view`` from the current tree state, then calls
        ``memory.recall`` to populate the ``memory`` field. The stub
        context passed to ``recall`` has ``memory=""`` — implementations
        must not depend on the ``memory`` field of their input context.
        """
        tree_view = self._tree.render_view()
        stub = PlanningContext(
            goal=self._goal,
            action_set=self._action_set,
            insights=insights,
            observation=observation,
            images=images,
            history=self._history,
            tree_view=tree_view,
            memory="",
        )
        memory_str = self._memory.recall(stub)
        if not memory_str:
            # NullMemory path: reuse the stub rather than building a second object.
            return stub
        return replace(stub, memory=memory_str)

    def _complete_pending(
        self,
        observation: str,
        images: list[Image] | None,
    ) -> Result | None:
        """COMPLETE phase: verify the pending action and check for early termination.

        Returns a terminal ``Result`` if the session ends here, ``None`` to
        continue on to ``_plan_next``.

        The commit point is the ``self._pending = None`` assignment: once cleared,
        a ``PlannerError`` raised in the subsequent PLAN phase will not re-verify
        on the next retry (``_pending`` is ``None``, so COMPLETE is skipped).
        """
        assert self._pending is not None
        pending_node = self._tree.node(self._pending)
        ctx = self._make_ctx(observation, images, self._insights)

        v = self._planner.verify(pending_node, ctx)
        pending_node.status = NodeStatus.SUCCESS if v.action_success else NodeStatus.NOT_RECOVERABLE

        # Commit point — clear pending before any further planner call.
        self._pending = None

        if v.action_success and v.goal_reached:
            self._terminal = Result(Status.GOAL_REACHED)
            return self._terminal

        self._t += 1
        if self._t >= self._T_max:
            self._terminal = Result(Status.HORIZON_REACHED)
            return self._terminal

        # TREE_UPDATE: let the planner propose nodes to prune; guards enforce safety.
        prune_ctx = self._make_ctx(observation, images, self._insights)
        prune_ids = self._planner.prune(pending_node, prune_ctx)
        apply_prune_guard(self._tree, self._stack, prune_ids)

        return None

    def _plan_next(
        self,
        observation: str,
        images: list[Image] | None,
    ) -> ActionNode | Result:
        """PLAN phase: synthesise insights, run the DFS, return the next action.

        Returns the next ``ActionNode`` when the DFS finds an ACTION leaf, or
        a terminal ``Result`` when the tree is exhausted.

        ``observation`` is appended to ``_history`` only after all
        potentially-raising planner calls complete (``form_insights``,
        ``expand``, ``recover``).  A ``PlannerError`` from any of those calls
        therefore leaves ``_history`` unmodified, so the step can be retried
        without duplicating the observation in history.
        """
        # form_insights receives insights=None (per spec — this IS the call that produces them).
        insights_ctx = self._make_ctx(observation, images, None)
        self._insights = self._planner.form_insights(insights_ctx)

        # Subsequent DFS calls see the freshly formed insights.
        ctx = self._make_ctx(observation, images, self._insights)
        node = get_action_node(self._tree, self._stack, self._planner, ctx)

        # All planner calls above have succeeded — safe to commit the observation to history.
        self._history.append(observation)

        if node is not None:
            self._pending = node.id
            return ActionNode(id=node.id, description=node.description, parent=node.parent)

        # DFS exhausted.
        root = self._tree.node(self._tree.root_id)
        self._terminal = (
            Result(Status.GOAL_REACHED)
            if root.status is NodeStatus.SUCCESS
            else Result(Status.FAILED)
        )
        return self._terminal


__all__ = [
    "ActionNode",
    "Insights",
    "Result",
    "SessionState",
    "Status",
    "Telos",
]
