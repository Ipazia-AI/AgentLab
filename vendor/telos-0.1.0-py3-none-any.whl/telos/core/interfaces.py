"""Internal protocol contracts and their DTOs.

``core/`` depends ONLY on the abstractions defined here — never on concrete
implementations in ``planner/`` or any LLM/network code.

These types are also exported from ``telos/__init__.py`` for typing and test fakes;
they are NOT part of the stable host-facing API (i.e. hosts embed TELOS via ``Telos``
and ``ActionNode``, not via these protocols).

Stability: medium — signatures are the Phase 2/3 build contract.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from typing import Literal, Protocol, runtime_checkable

from telos.core.model import Node, NodeId, NodeType

# ---------------------------------------------------------------------------
# PlannerLLM — the only LLM dependency; host-supplied at construction time.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Image:
    """A single image block passed alongside an observation."""

    data: bytes
    media_type: str  # e.g. "image/png", "image/jpeg"


@dataclass(frozen=True)
class ChatMessage:
    """A single message in a chat prompt."""

    role: Literal["system", "user", "assistant"]
    content: str | list[str | Image]  # text, or mixed text + image blocks


@runtime_checkable
class PlannerLLM(Protocol):
    """Provider-agnostic LLM interface: text (+ optional images) in, text out.

    The host supplies the concrete implementation (provider, credentials, model,
    retries, timeouts). Raising any exception is allowed; ``planner/`` wraps it
    as ``PlannerError``.
    """

    def complete(self, messages: Sequence[ChatMessage]) -> str:
        """Turn a chat prompt into a single completion string."""
        ...


# ---------------------------------------------------------------------------
# Planner DTOs
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Insights:
    """Ephemeral per-session synthesis formed before each planning step."""

    constraints: str
    progress: str
    suggestion: str


@dataclass(frozen=True)
class Expansion:
    """What the planner returns when asked to expand an UNKNOWN node."""

    type: NodeType  # ACTION, AND, or OR (never UNKNOWN)
    description: str  # refined target-state description for the node
    children: list[str]  # child target-state descriptions; empty iff type == ACTION


@dataclass(frozen=True)
class Verification:
    """Result of a single verify call against the latest observation."""

    action_success: bool
    goal_reached: bool


@dataclass(frozen=True)
class PlanningContext:
    """Read-only snapshot that ``core/`` hands to the planner for a reasoning call."""

    goal: str
    action_set: str
    insights: Insights | None  # None only on the form_insights call that produces it
    observation: str
    images: list[Image] | None  # optional screenshots; None for text-only hosts
    history: Sequence[str]
    tree_view: str  # rendered "Plan Context" tree (ids, types, statuses, descriptions)
    memory: str  # knowledge recalled for this step ("" when NullMemory)


# ---------------------------------------------------------------------------
# Planner protocol — implemented in planner/; called by core/ and facade.py
# ---------------------------------------------------------------------------


@runtime_checkable
class Planner(Protocol):
    """The reasoning layer that ``core/`` calls for each LLM-backed step.

    ``core/`` calls methods here; only ``planner/`` implements them.
    The planner NEVER mutates the tree — it returns data and ``core/`` applies it.
    """

    def form_insights(self, ctx: PlanningContext) -> Insights:
        """Synthesise constraints, progress, and suggestions for the current step."""
        ...

    def expand(self, node: Node, ctx: PlanningContext) -> Expansion:
        """Turn an UNKNOWN node into AND/OR/ACTION children."""
        ...

    def recover(self, node: Node, children: Sequence[Node], ctx: PlanningContext) -> list[str]:
        """Propose alternative child descriptions for a failed node."""
        ...

    def verify(self, node: Node, ctx: PlanningContext) -> Verification:
        """Check whether the pending step reached its target and the goal is met."""
        ...

    def prune(self, node: Node, ctx: PlanningContext) -> list[NodeId]:
        """Propose stale/redundant node IDs to delete; node is the just-completed node."""
        ...


# ---------------------------------------------------------------------------
# Memory protocol — TELOS-internal; cross-session knowledge base (not host-injected)
# ---------------------------------------------------------------------------


@runtime_checkable
class Memory(Protocol):
    """Cross-session knowledge base behind a stable interface.

    ``core/`` depends only on this protocol. The concrete store (schema, retrieval,
    eviction) is deferred to a follow-up ADR (ADR-0005).
    """

    def recall(self, ctx: PlanningContext) -> str:
        """Return cross-session knowledge relevant to the current step, as prompt text."""
        ...
