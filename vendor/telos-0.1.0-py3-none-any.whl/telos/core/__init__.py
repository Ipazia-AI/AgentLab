# core/ — deterministic AND/OR tree engine (no LLM, no I/O).
# Public surface is internal to TELOS; nothing here is part of the host-facing API.
