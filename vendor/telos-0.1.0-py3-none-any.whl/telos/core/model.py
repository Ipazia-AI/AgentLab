"""Internal data model for the AND/OR plan tree.

Defines the node types, statuses, traversal state, node record, and tree
structure that the deterministic engine operates on.

Stability: medium — signatures here are the contract Phase 2 builds against.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, TypeAlias

# Dotted hierarchical node path (e.g. "0", "0.1", "0.1.2").
# The root is always "0"; a new child of X is f"{X}.{k}" where k is a
# per-parent monotonic counter (see Tree.add_child).
NodeId: TypeAlias = str


class NodeType(Enum):
    """The four node kinds in the AND/OR plan tree."""

    UNKNOWN = auto()
    ACTION = auto()
    AND = auto()
    OR = auto()


class NodeStatus(Enum):
    """Node lifecycle statuses.

    Inert statuses (never re-processed): SUCCESS, NOT_RECOVERABLE, EXHAUSTED, DELETED.
    """

    UNVISITED = auto()
    VISITED = auto()
    SUCCESS = auto()
    RECOVERABLE = auto()
    NOT_RECOVERABLE = auto()
    EXHAUSTED = auto()
    DELETED = auto()


class StackState(Enum):
    """Per-stack-entry traversal state; NOT stored on the node itself."""

    ENTERING = auto()
    EXITING = auto()
    FAILED = auto()


@dataclass
class Node:
    """Mutable internal record for a single plan-tree node.

    Distinct from the frozen ``ActionNode`` that crosses the public boundary.
    ``core/`` never parses ``description`` — it is an opaque string.
    """

    id: NodeId
    type: NodeType
    status: NodeStatus
    description: str  # NL target-state; goal text for the root UNKNOWN node
    parent: NodeId | None
    children: list[NodeId] = field(default_factory=list)
    _next_child_index: int = field(default=1, repr=False)

    def to_dict(self) -> dict[str, Any]:
        """Serialize this node to a JSON-compatible dict.

        Enum fields are serialized by name (e.g. ``"ACTION"``, ``"VISITED"``).
        The per-parent monotonic counter is preserved as ``next_child_index``.
        """
        return {
            "id": self.id,
            "type": self.type.name,
            "status": self.status.name,
            "description": self.description,
            "parent": self.parent,
            "children": list(self.children),
            "next_child_index": self._next_child_index,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Node:
        """Reconstruct a node from a dict produced by ``to_dict``."""
        node = cls(
            id=d["id"],
            type=NodeType[d["type"]],
            status=NodeStatus[d["status"]],
            description=d["description"],
            parent=d["parent"],
            children=list(d["children"]),
        )
        node._next_child_index = d["next_child_index"]
        return node


class Tree:
    """The held AND/OR plan tree G(N,E).

    Owns node lookup and child creation. The root node always has id ``"0"``.
    Child IDs are assigned by ``add_child`` using a per-parent monotonic counter
    so IDs remain unique and stable even after siblings are deleted or new
    children are appended during recovery.
    """

    def __init__(self, goal: str) -> None:
        """Initialise with a single root UNKNOWN node whose description is *goal*."""
        self.root_id: NodeId = "0"
        self._nodes: dict[NodeId, Node] = {}
        root = Node(
            id="0",
            type=NodeType.UNKNOWN,
            status=NodeStatus.UNVISITED,
            description=goal,
            parent=None,
        )
        self._nodes["0"] = root

    def node(self, nid: NodeId) -> Node:
        """Return the node for *nid*. Raises ``KeyError`` if not found."""
        return self._nodes[nid]

    def children(self, nid: NodeId) -> list[Node]:
        """Return the live (non-DELETED) children of *nid* in insertion order."""
        parent = self._nodes[nid]
        return [
            self._nodes[child_id]
            for child_id in parent.children
            if self._nodes[child_id].status != NodeStatus.DELETED
        ]

    def add_child(
        self,
        parent_id: NodeId,
        *,
        type: NodeType,
        status: NodeStatus,
        description: str,
    ) -> Node:
        """Append a new child to *parent_id*, assign the next NodeId, link edges.

        The ``_next_child_index`` on the parent is incremented; the counter never
        reuses a value, even after sibling deletion.
        """
        parent = self._nodes[parent_id]
        child_id = f"{parent_id}.{parent._next_child_index}"
        parent._next_child_index += 1
        child = Node(
            id=child_id,
            type=type,
            status=status,
            description=description,
            parent=parent_id,
        )
        self._nodes[child_id] = child
        parent.children.append(child_id)
        return child

    def render_view(self) -> str:
        """Return a human-readable rendering of the full plan tree.

        Each node is shown with its id, type, status, and description.
        DELETED nodes are included so the planner sees attempted paths.
        Used as ``tree_view`` in ``PlanningContext``.
        """
        lines: list[str] = []
        self._render_node(self.root_id, depth=0, lines=lines)
        return "\n".join(lines)

    def to_dict(self) -> dict[str, Any]:
        """Serialize the full tree to a JSON-compatible dict.

        All nodes are included (including ``DELETED`` ones) so that the planner
        can see attempted paths on hydration. Insertion order of nodes is
        preserved; ``_next_child_index`` is stored as ``next_child_index`` on
        each node dict.
        """
        return {
            "root_id": self.root_id,
            "nodes": [n.to_dict() for n in self._nodes.values()],
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Tree:
        """Reconstruct a tree from a dict produced by ``to_dict``.

        Bypasses ``__init__`` (which would create a fresh root node) and
        restores the full node map directly.
        """
        tree: Tree = object.__new__(cls)
        tree.root_id = d["root_id"]
        tree._nodes = {}
        for node_data in d["nodes"]:
            node = Node.from_dict(node_data)
            tree._nodes[node.id] = node
        return tree

    def _render_node(self, nid: NodeId, depth: int, lines: list[str]) -> None:
        n = self._nodes[nid]
        indent = "  " * depth
        lines.append(f"{indent}[{n.id}] {n.type.name} {n.status.name}: {n.description!r}")
        for child_id in n.children:
            self._render_node(child_id, depth + 1, lines)
