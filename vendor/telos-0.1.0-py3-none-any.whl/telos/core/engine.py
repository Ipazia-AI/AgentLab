"""Deterministic DFS engine: GET_ACTION_NODE, PROCESS_*, PROPAGATE_FAILURE,
TREE_UPDATE prune-guards, and tree predicates.

No LLM or network dependencies — all reasoning goes through the Planner protocol.

Implementation notes:
1. SUCCESS and EXHAUSTED are treated as inert in the DFS loop (like DELETED),
   per the tech-spec §9 "inert — never re-processed" contract.
2. SUCCESSFUL_AND/OR sets ``n.status = SUCCESS`` inline on the early return from
   PROCESS_ENTERING, since PROCESS_EXITING is never reached in that path.
3. Post-recovery viability guard (PROCESS_ENTERING in the algorithm spec): a
   recovered AND/OR with no new UNVISITED children cannot make progress, so it
   is marked NOT_RECOVERABLE and its failure is propagated. It runs *before* the
   SUCCESSFUL_AND/OR check so that a required AND child left EXHAUSTED with no
   replacement is not mistaken for SUCCESS (it also prevents an infinite
   recovery loop when recovery yields nothing).
"""

from __future__ import annotations

from telos.core.interfaces import Expansion, Planner, PlanningContext
from telos.core.model import Node, NodeId, NodeStatus, NodeType, StackState, Tree


def get_action_node(
    tree: Tree,
    stack: list[tuple[NodeId, StackState]],
    planner: Planner,
    ctx: PlanningContext,
) -> Node | None:
    """Run the DFS until an ACTION leaf is found or the tree is exhausted.

    Returns the next ACTION ``Node`` to execute, or ``None`` when the DFS is
    exhausted.
    """
    while stack:
        nid, state = stack.pop()
        n = tree.node(nid)

        if n.status is NodeStatus.NOT_RECOVERABLE:
            _propagate_failure(tree, stack, n)
            continue
        if n.status in (NodeStatus.DELETED, NodeStatus.EXHAUSTED, NodeStatus.SUCCESS):
            continue

        if state is StackState.ENTERING:
            m = _process_entering(tree, stack, planner, ctx, n)
            if m.type is NodeType.ACTION:
                return m
        elif state is StackState.EXITING:
            _process_exiting(tree, stack, n)
        else:
            _process_failed(tree, stack, n)

    return None


def _process_entering(
    tree: Tree,
    stack: list[tuple[NodeId, StackState]],
    planner: Planner,
    ctx: PlanningContext,
    n: Node,
) -> Node:
    """PROCESS_ENTERING per the algorithm spec.

    AND children are pushed in reverse so the first child ends up on top of the
    stack and is processed first.
    """
    recovered = False
    if n.status is NodeStatus.RECOVERABLE:
        _planner_recover(tree, planner, ctx, n)
        n.status = NodeStatus.VISITED
        recovered = True
    elif n.type is NodeType.UNKNOWN:
        _planner_expand(tree, planner, ctx, n)
        n.status = NodeStatus.VISITED

    if n.type is NodeType.ACTION:
        stack.append((n.id, StackState.EXITING))
        return n

    all_kids = _all_children(tree, n.id)

    if all_kids and _all_deleted(all_kids):
        n.status = NodeStatus.DELETED
        return n

    if recovered and not any(c.status is NodeStatus.UNVISITED for c in all_kids):
        n.status = NodeStatus.NOT_RECOVERABLE
        _propagate_failure(tree, stack, n)
        return n

    success = _successful_and(all_kids) if n.type is NodeType.AND else _successful_or(all_kids)
    if success:
        n.status = NodeStatus.SUCCESS
        return n

    if n.type is NodeType.AND:
        stack.append((n.id, StackState.EXITING))
        if _valid_and(all_kids):
            for c in reversed(all_kids):
                stack.append((c.id, StackState.ENTERING))
        else:
            n.status = NodeStatus.RECOVERABLE
    else:
        stack.append((n.id, StackState.EXITING))
        promising = _select_promising(all_kids)
        if promising is not None:
            stack.append((promising.id, StackState.ENTERING))
        else:
            n.status = NodeStatus.RECOVERABLE

    return n


def _process_exiting(
    tree: Tree,
    stack: list[tuple[NodeId, StackState]],
    n: Node,
) -> None:
    """PROCESS_EXITING per the algorithm spec."""
    if n.type is NodeType.ACTION:
        if n.status in (NodeStatus.RECOVERABLE, NodeStatus.NOT_RECOVERABLE):
            stack.append((n.id, StackState.FAILED))
        return

    all_kids = _all_children(tree, n.id)
    if (n.type is NodeType.AND and _successful_and(all_kids)) or (
        n.type is NodeType.OR and _successful_or(all_kids)
    ):
        n.status = NodeStatus.SUCCESS
        return

    if n.status is not NodeStatus.RECOVERABLE:
        n.status = NodeStatus.RECOVERABLE
    stack.append((n.id, StackState.FAILED))


def _process_failed(
    tree: Tree,
    stack: list[tuple[NodeId, StackState]],
    n: Node,
) -> None:
    """PROCESS_FAILED per the algorithm spec."""
    if n.type is NodeType.ACTION:
        n.status = NodeStatus.NOT_RECOVERABLE
        _propagate_failure(tree, stack, n)
        return

    if n.status is not NodeStatus.RECOVERABLE:
        n.status = NodeStatus.RECOVERABLE
    stack.append((n.id, StackState.ENTERING))


def _propagate_failure(
    tree: Tree,
    stack: list[tuple[NodeId, StackState]],
    n: Node,
) -> None:
    """PROPAGATE_FAILURE per the algorithm spec."""
    if n.parent is None:
        return

    parent = tree.node(n.parent)
    deleted_ids: set[NodeId] = set()

    if parent.type is NodeType.AND:
        for child_id in parent.children:
            deleted_ids |= _mark_deleted_subtree(tree, tree.node(child_id))
    elif parent.type is NodeType.OR:
        deleted_ids |= _mark_deleted_subtree(tree, n)

    if deleted_ids:
        stack[:] = [(nid, st) for nid, st in stack if nid not in deleted_ids]

    if parent.status not in (NodeStatus.NOT_RECOVERABLE, NodeStatus.DELETED):
        parent.status = NodeStatus.RECOVERABLE


def _mark_deleted_subtree(tree: Tree, n: Node) -> set[NodeId]:
    """MARK_DELETED_SUBTREE per the algorithm spec.

    Preserves SUCCESS, NOT_RECOVERABLE, and EXHAUSTED nodes. Recurses over the
    raw child list (all children, including already-DELETED) rather than the
    live ``Tree.children()`` accessor, which filters DELETED out.
    Returns the set of NodeIds that were marked DELETED.
    """
    if n.status in (NodeStatus.SUCCESS, NodeStatus.NOT_RECOVERABLE, NodeStatus.EXHAUSTED):
        return set()

    n.status = NodeStatus.DELETED
    deleted: set[NodeId] = {n.id}
    for child_id in n.children:
        deleted |= _mark_deleted_subtree(tree, tree.node(child_id))
    return deleted


def _planner_expand(
    tree: Tree,
    planner: Planner,
    ctx: PlanningContext,
    n: Node,
) -> None:
    """Expand an UNKNOWN node: set its type/description and create child nodes."""
    expansion: Expansion = planner.expand(n, ctx)
    n.type = expansion.type
    n.description = expansion.description
    if expansion.type in (NodeType.AND, NodeType.OR):
        for child_desc in expansion.children:
            tree.add_child(
                n.id,
                type=NodeType.UNKNOWN,
                status=NodeStatus.UNVISITED,
                description=child_desc,
            )


def _planner_recover(
    tree: Tree,
    planner: Planner,
    ctx: PlanningContext,
    n: Node,
) -> None:
    """Add new children from recovery; mark permanently-failed old ones EXHAUSTED."""
    live_children = tree.children(n.id)
    new_descs = planner.recover(n, live_children, ctx)

    for desc in new_descs:
        tree.add_child(
            n.id,
            type=NodeType.UNKNOWN,
            status=NodeStatus.UNVISITED,
            description=desc,
        )

    for child_id in n.children:
        child = tree.node(child_id)
        if child.status is NodeStatus.NOT_RECOVERABLE:
            child.status = NodeStatus.EXHAUSTED


def apply_prune_guard(
    tree: Tree,
    stack: list[tuple[NodeId, StackState]],
    candidate_ids: list[NodeId],
) -> set[NodeId]:
    """Apply deterministic prune guards to planner-proposed node IDs.

    Never deletes VISITED, SUCCESS, NOT_RECOVERABLE, or EXHAUSTED nodes.
    Never deletes UNVISITED children of OR parents (untried alternatives).
    Removes actually-deleted node IDs from the DFS stack.
    Returns the set of IDs that were actually marked DELETED.
    """
    _PROTECTED = frozenset(
        {
            NodeStatus.VISITED,
            NodeStatus.SUCCESS,
            NodeStatus.NOT_RECOVERABLE,
            NodeStatus.EXHAUSTED,
        }
    )

    deleted: set[NodeId] = set()
    for nid in candidate_ids:
        try:
            n = tree.node(nid)
        except KeyError:
            continue

        if n.status in _PROTECTED:
            continue

        if n.status is NodeStatus.UNVISITED and n.parent is not None:
            parent = tree.node(n.parent)
            if parent.type is NodeType.OR:
                continue

        n.status = NodeStatus.DELETED
        deleted.add(nid)

    if deleted:
        stack[:] = [(nid, st) for nid, st in stack if nid not in deleted]

    return deleted


def _all_children(tree: Tree, nid: NodeId) -> list[Node]:
    """Return ALL children of *nid* including DELETED, in insertion order."""
    return [tree.node(child_id) for child_id in tree.node(nid).children]


def _successful_and(children: list[Node]) -> bool:
    """SUCCESSFUL_AND: all in {success, deleted, exhausted} and ≥ 1 success."""
    if not children:
        return False
    allowed = (NodeStatus.SUCCESS, NodeStatus.DELETED, NodeStatus.EXHAUSTED)
    return all(c.status in allowed for c in children) and any(
        c.status is NodeStatus.SUCCESS for c in children
    )


def _successful_or(children: list[Node]) -> bool:
    """SUCCESSFUL_OR: at least one child is SUCCESS."""
    return any(c.status is NodeStatus.SUCCESS for c in children)


def _valid_and(children: list[Node]) -> bool:
    """VALID_AND: no child is NOT_RECOVERABLE."""
    return all(c.status is not NodeStatus.NOT_RECOVERABLE for c in children)


def _valid_or(children: list[Node]) -> bool:
    """VALID_OR: at least one child not in {not_recoverable, deleted, exhausted}."""
    blocked = (NodeStatus.NOT_RECOVERABLE, NodeStatus.DELETED, NodeStatus.EXHAUSTED)
    return any(c.status not in blocked for c in children)


def _all_deleted(children: list[Node]) -> bool:
    """ALL_DELETED: every child is DELETED."""
    return all(c.status is NodeStatus.DELETED for c in children)


def _select_promising(children: list[Node]) -> Node | None:
    """SELECT_PROMISING: first child not in {not_recoverable, deleted, exhausted}."""
    blocked = (NodeStatus.NOT_RECOVERABLE, NodeStatus.DELETED, NodeStatus.EXHAUSTED)
    return next((c for c in children if c.status not in blocked), None)
