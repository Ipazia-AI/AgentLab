"""TELOS — a standalone, embeddable planning module for host agents.

Public surface (stable host-facing API):

    from telos import Telos, ActionNode, Result, Status
    from telos import PlannerLLM, ChatMessage, Image
    from telos import TelosError, PlannerError, UsageError

``OpenRouterPlanner`` is available as a convenience adapter when the
``openai`` package is installed.  It is imported lazily so that the core
library works without it — importing ``telos`` never requires ``openai``.

``Planner`` and ``Memory`` are internal protocols exported here only for typing
and test fakes.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from telos.core.interfaces import (
    ChatMessage,
    Image,
    Memory,
    Planner,
    PlannerLLM,
)
from telos.errors import PlannerError, TelosError, UsageError
from telos.facade import ActionNode, Result, SessionState, Status, Telos

if TYPE_CHECKING:
    from telos.planner.openrouter import OpenRouterPlanner

__all__ = [
    # Core public API
    "Telos",
    "ActionNode",
    "Result",
    "SessionState",
    "Status",
    # Host-facing protocols / types
    "PlannerLLM",
    "ChatMessage",
    "Image",
    # Concrete LLM adapters — openai package required (optional install)
    "OpenRouterPlanner",
    # Errors
    "TelosError",
    "PlannerError",
    "UsageError",
    # Internal protocols — exported for typing and test fakes only
    "Planner",
    "Memory",
]


def __getattr__(name: str) -> object:
    """Lazy-load optional adapters that carry heavy optional dependencies.

    ``OpenRouterPlanner`` depends on ``openai``; deferring its import keeps
    ``import telos`` free of that requirement for users who do not use it.
    """
    if name == "OpenRouterPlanner":
        from telos.planner.openrouter import OpenRouterPlanner

        return OpenRouterPlanner
    raise AttributeError(f"module 'telos' has no attribute {name!r}")
