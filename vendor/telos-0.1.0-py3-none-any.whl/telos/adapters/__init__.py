# adapters/ — reserved for future environment-format translation.
# Empty for now; environment input translation stays host-side until an ADR authorises it.
