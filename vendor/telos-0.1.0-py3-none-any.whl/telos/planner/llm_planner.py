"""LLM-backed implementation of the ``Planner`` protocol.

``LLMPlanner`` is the concrete ``Planner`` that drives the AND/OR tree using a
host-supplied ``PlannerLLM``. It delegates prompt construction to ``prompts.py``
and response parsing to ``parsing.py``, wrapping any exception as ``PlannerError``.

This is the ONLY place LLM/network calls are made in TELOS.
"""

from __future__ import annotations

import re
from collections.abc import Sequence

from telos.core.interfaces import (
    ChatMessage,
    Expansion,
    Insights,
    PlannerLLM,
    PlanningContext,
    Verification,
)
from telos.core.model import Node, NodeId, NodeType
from telos.errors import PlannerError
from telos.planner.parsing import (
    parse_expansion,
    parse_insights,
    parse_prune,
    parse_recovery,
    parse_verification,
)
from telos.planner.prompts import (
    build_and_recovery_prompt,
    build_insights_prompt,
    build_or_recovery_prompt,
    build_planning_prompt,
    build_prune_prompt,
    build_verification_prompt,
)

# Matches bracketed node IDs in the rendered tree_view, e.g. "[0]", "[0.1]", "[0.2.3]".
_NODE_ID_RE = re.compile(r"\[(\d+(?:\.\d+)*)\]")


def _extract_valid_ids(tree_view: str) -> frozenset[NodeId]:
    """Return all node IDs present in a rendered tree_view string."""
    return frozenset(_NODE_ID_RE.findall(tree_view))


class LLMPlanner:
    """Concrete ``Planner`` backed by a host-supplied ``PlannerLLM``.

    Wraps all ``PlannerLLM.complete`` calls so that any provider/transport
    exception is caught and re-raised as ``PlannerError``. Raw provider errors
    never leak to the host. ``PlannerError`` raised by parse functions propagates
    unchanged — it is never double-wrapped.
    """

    def __init__(self, planner_llm: PlannerLLM) -> None:
        self._llm = planner_llm

    def _complete(self, messages: Sequence[ChatMessage]) -> str:
        """Call the underlying LLM; re-raise any exception as ``PlannerError``."""
        try:
            return self._llm.complete(messages)
        except Exception as exc:
            raise PlannerError(f"PlannerLLM.complete raised: {exc}") from exc

    def form_insights(self, ctx: PlanningContext) -> Insights:
        """Call PROMPT_INSIGHTS and parse the result into an ``Insights`` DTO."""
        messages = build_insights_prompt(ctx)
        response = self._complete(messages)
        return parse_insights(response)

    def expand(self, node: Node, ctx: PlanningContext) -> Expansion:
        """Call PLANNER_EXPAND and parse the result into an ``Expansion`` DTO."""
        messages = build_planning_prompt(node, ctx)
        response = self._complete(messages)
        return parse_expansion(response)

    def recover(self, node: Node, children: Sequence[Node], ctx: PlanningContext) -> list[str]:
        """Call PLANNER_RECOVER (AND or OR variant) and return new child descriptions."""
        if node.type is NodeType.AND:
            messages = build_and_recovery_prompt(node, children, ctx)
        else:
            messages = build_or_recovery_prompt(node, children, ctx)
        response = self._complete(messages)
        return parse_recovery(response)

    def verify(self, node: Node, ctx: PlanningContext) -> Verification:
        """Call PROMPT_VERIFY and parse the result into a ``Verification`` DTO."""
        messages = build_verification_prompt(node, ctx)
        response = self._complete(messages)
        return parse_verification(response)

    def prune(self, node: Node, ctx: PlanningContext) -> list[NodeId]:
        """Call PROMPT_PRUNE and return node IDs to delete (best-effort).

        Hallucinated IDs are silently dropped at parse time by cross-referencing
        the node IDs extracted from ``ctx.tree_view``.  A malformed response
        returns ``[]`` rather than raising — pruning is an optimisation, not
        correctness-critical.
        """
        messages = build_prune_prompt(node, ctx)
        response = self._complete(messages)
        valid_ids = _extract_valid_ids(ctx.tree_view)
        return parse_prune(response, valid_ids)


__all__ = ["LLMPlanner"]
