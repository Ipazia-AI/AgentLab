"""XML-tag extraction and response validation for planner outputs.

All LLM responses are XML-tagged (e.g. ``<node_type>``, ``<node_description>``,
``<verification_result>``, ``<goal_reached>``, …). Parsing is tolerant of
surrounding prose and minor whitespace.

Key rules:
- Extract by tag; collect repeated tags in order.
- ``recover`` output uses a single ``<recovery_expansion>`` block (newline-split),
  NOT the ``<node_expansion>`` collector.
- Verdict tokens are normalised case-insensitively.
- ``prune`` IDs not present in the current tree are silently dropped.
- A missing required field raises ``PlannerError``; a malformed ``prune`` response
  is treated as an empty list (pruning is best-effort).
"""

from __future__ import annotations

import json
import re

from telos.core.interfaces import Expansion, Insights, Verification
from telos.core.model import NodeId, NodeType
from telos.errors import PlannerError

_DOTALL = re.DOTALL

_NODE_TYPE_MAP: dict[str, NodeType] = {
    "action": NodeType.ACTION,
    "and": NodeType.AND,
    "or": NodeType.OR,
}

_VERDICT_MAP: dict[str, bool] = {
    "success": True,
    "failure": False,
}

_GOAL_MAP: dict[str, bool] = {
    "yes": True,
    "no": False,
}


def _extract_first(tag: str, text: str) -> str | None:
    """Return the stripped inner content of the first ``<tag>…</tag>``, or ``None``."""
    m = re.search(rf"<{re.escape(tag)}>(.*?)</{re.escape(tag)}>", text, _DOTALL)
    return m.group(1).strip() if m else None


def _extract_all(tag: str, text: str) -> list[str]:
    """Return stripped inner content of every ``<tag>…</tag>`` in insertion order."""
    return [
        m.group(1).strip()
        for m in re.finditer(rf"<{re.escape(tag)}>(.*?)</{re.escape(tag)}>", text, _DOTALL)
    ]


def parse_insights(response: str) -> Insights:
    """Extract ``<constraints>``, ``<progress>``, ``<suggestion>`` tags."""
    constraints = _extract_first("constraints", response)
    progress = _extract_first("progress", response)
    suggestion = _extract_first("suggestion", response)

    missing = [
        name
        for name, val in (
            ("constraints", constraints),
            ("progress", progress),
            ("suggestion", suggestion),
        )
        if val is None
    ]
    if missing:
        raise PlannerError(
            f"Missing required tag(s) in insights response: {', '.join(f'<{t}>' for t in missing)}"
        )

    assert constraints is not None and progress is not None and suggestion is not None
    return Insights(constraints=constraints, progress=progress, suggestion=suggestion)


def parse_expansion(response: str) -> Expansion:
    """Extract ``<node_type>``, ``<node_description>``, and ``<node_expansion>`` tags."""
    raw_type = _extract_first("node_type", response)
    if raw_type is None:
        raise PlannerError("Missing required tag <node_type> in expansion response")

    node_type = _NODE_TYPE_MAP.get(raw_type.lower())
    if node_type is None:
        raise PlannerError(f"Unrecognised node_type value: {raw_type!r}")

    description = _extract_first("node_description", response)
    if description is None:
        raise PlannerError("Missing required tag <node_description> in expansion response")

    if node_type is NodeType.ACTION:
        children: list[str] = []
    else:
        children = _extract_all("node_expansion", response)
        if not children:
            raise PlannerError(
                f"Missing required <node_expansion> tag(s) for {node_type.name} node"
                " in expansion response"
            )

    return Expansion(type=node_type, description=description, children=children)


def parse_recovery(response: str) -> list[str]:
    """Extract new child descriptions from a single ``<recovery_expansion>`` block.

    Splits the block on newlines, strips each line, and drops blanks.
    Returns ``[]`` when the tag is absent (empty recovery is valid).
    """
    content = _extract_first("recovery_expansion", response)
    if content is None:
        return []
    return [line for line in (ln.strip() for ln in content.splitlines()) if line]


def parse_verification(response: str) -> Verification:
    """Extract ``<verification_result>`` and ``<goal_reached>`` tags."""
    raw_result = _extract_first("verification_result", response)
    if raw_result is None:
        raise PlannerError("Missing required tag <verification_result> in verification response")

    raw_goal = _extract_first("goal_reached", response)
    if raw_goal is None:
        raise PlannerError("Missing required tag <goal_reached> in verification response")

    action_success = _VERDICT_MAP.get(raw_result.lower())
    if action_success is None:
        raise PlannerError(f"Unrecognised verification_result value: {raw_result!r}")

    goal_reached = _GOAL_MAP.get(raw_goal.lower())
    if goal_reached is None:
        raise PlannerError(f"Unrecognised goal_reached value: {raw_goal!r}")

    return Verification(action_success=action_success, goal_reached=goal_reached)


def parse_prune(response: str, valid_ids: frozenset[NodeId]) -> list[NodeId]:
    """Extract prune node IDs; silently drop any ID not in *valid_ids*.

    Returns ``[]`` on any JSON parse error or missing ``prune`` key —
    pruning is best-effort and a malformed response must not fail the step.
    """
    try:
        data = json.loads(response)
        ids = data.get("prune", [])
        if not isinstance(ids, list):
            return []
        return [nid for nid in ids if nid in valid_ids]
    except (json.JSONDecodeError, AttributeError, TypeError):
        return []
