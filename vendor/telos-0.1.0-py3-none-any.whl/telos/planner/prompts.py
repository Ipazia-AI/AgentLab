"""Prompt builders for each Planner method.

Each ``PROMPT_*`` builder returns a ``Sequence[ChatMessage]`` (system + user)
assembled from the canonical prompt templates, with placeholders filled from
a ``PlanningContext`` and the target ``Node``.

When ``ctx.images`` is non-empty the builder appends each as an ``Image`` block
to the user message that carries ``{observation}``.
"""

from __future__ import annotations

import importlib.resources
from collections.abc import Sequence
from typing import Any

import yaml

from telos.core.interfaces import ChatMessage, Image, PlanningContext
from telos.core.model import Node

# ---------------------------------------------------------------------------
# Load prompt templates from the co-located YAML file at import time.
# ---------------------------------------------------------------------------

_pkg = importlib.resources.files("telos.planner")
_raw = (_pkg / "prompts.yaml").read_text(encoding="utf-8")
_templates: dict[str, Any] = yaml.safe_load(_raw)

_SYSTEM_INSIGHT: str = _templates["SYSTEM_INSIGHT"]
_SYSTEM_PLANNING: str = _templates["SYSTEM_PLANNING"]
_SYSTEM_VERIFICATION: str = _templates["SYSTEM_VERIFICATION"]
_SYSTEM_PRUNE_TEMPLATE: str = _templates["SYSTEM_PRUNE_TEMPLATE"]
_INSIGHT_INSTRUCTIONS: str = _templates["INSIGHT_INSTRUCTIONS"]
_INSIGHT_ABSTRACT_EXAMPLE: str = _templates["INSIGHT_ABSTRACT_EXAMPLE"]
_INSIGHT_CONCRETE_EXAMPLE: str = _templates["INSIGHT_CONCRETE_EXAMPLE"]
_PLANNING_INSTRUCTIONS: str = _templates["PLANNING_INSTRUCTIONS"]
_PLANNING_HINTS: str = _templates["PLANNING_HINTS"]
_PLANNING_ABSTRACT_EXAMPLE: str = _templates["PLANNING_ABSTRACT_EXAMPLE"]
_PLANNING_CONCRETE_EXAMPLES: str = _templates["PLANNING_CONCRETE_EXAMPLES"]
_AND_RECOVERY_BODY: str = _templates["AND_RECOVERY_BODY"]
_OR_RECOVERY_BODY: str = _templates["OR_RECOVERY_BODY"]
_RECOVERY_ABSTRACT_EXAMPLE: str = _templates["RECOVERY_ABSTRACT_EXAMPLE"]
_VERIFICATION_RULES: str = _templates["VERIFICATION_RULES"]
_VERIFICATION_ANSWER_FORMAT: str = _templates["VERIFICATION_ANSWER_FORMAT"]


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _observation_block(ctx: PlanningContext) -> str:
    return f"# Observation of current step:\n{ctx.observation}"


def _make_user_message(text: str, images: list[Image] | None) -> ChatMessage:
    if images:
        content: str | list[str | Image] = [text, *images]
    else:
        content = text
    return ChatMessage(role="user", content=content)


def _render_children_status(children: Sequence[Node]) -> str:
    return "\n".join(f"[{child.status.name}] {child.description}" for child in children)


# ---------------------------------------------------------------------------
# Public builders
# ---------------------------------------------------------------------------


def build_insights_prompt(ctx: PlanningContext) -> Sequence[ChatMessage]:
    """Build the PROMPT_INSIGHTS messages."""
    parts: list[str] = [
        _INSIGHT_INSTRUCTIONS.format(goal=ctx.goal),
        _observation_block(ctx),
    ]
    if ctx.memory:
        parts.append(f"# Memory:\n{ctx.memory}")
    parts.append(_INSIGHT_ABSTRACT_EXAMPLE)
    parts.append(_INSIGHT_CONCRETE_EXAMPLE)

    user_text = "\n\n".join(parts)
    return [
        ChatMessage(role="system", content=_SYSTEM_INSIGHT),
        _make_user_message(user_text, ctx.images),
    ]


def build_planning_prompt(node: Node, ctx: PlanningContext) -> Sequence[ChatMessage]:
    """Build the PLANNER_EXPAND messages."""
    if ctx.insights is None:
        raise ValueError("ctx.insights must be set before calling build_planning_prompt")
    hints = _PLANNING_HINTS.format(
        constraints=ctx.insights.constraints,
        progress=ctx.insights.progress,
        suggestion=ctx.insights.suggestion,
        tree_context=ctx.tree_view,
    )
    node_to_expand = f"# NODE TO EXPAND:\n{node.id}: {node.description}"

    parts = [
        _PLANNING_INSTRUCTIONS.format(goal=ctx.goal),
        _observation_block(ctx),
        hints,
        node_to_expand,
        _PLANNING_ABSTRACT_EXAMPLE,
        _PLANNING_CONCRETE_EXAMPLES,
    ]
    user_text = "\n\n".join(parts)
    return [
        ChatMessage(role="system", content=_SYSTEM_PLANNING),
        _make_user_message(user_text, ctx.images),
    ]


def build_verification_prompt(node: Node, ctx: PlanningContext) -> Sequence[ChatMessage]:
    """Build the PROMPT_VERIFY messages."""
    header = (
        "# Action Verification\n\n"
        "An action was just executed. Your task is to determine whether the action's target state\n"
        "was achieved, and whether the overall session goal is now met.\n\n"
        f"## Session goal:\n{ctx.goal}\n\n"
        f"## Step target state:\n{node.description}"
    )
    parts = [
        header,
        _VERIFICATION_RULES,
        _observation_block(ctx),
        _VERIFICATION_ANSWER_FORMAT,
    ]
    user_text = "\n\n".join(parts)
    return [
        ChatMessage(role="system", content=_SYSTEM_VERIFICATION),
        _make_user_message(user_text, ctx.images),
    ]


def _build_recovery_prompt(
    body_template: str,
    node: Node,
    children: Sequence[Node],
    ctx: PlanningContext,
) -> Sequence[ChatMessage]:
    body = body_template.format(
        node_id=node.id,
        node_description=node.description,
        children_status=_render_children_status(children),
    )
    parts = [body, _observation_block(ctx), _RECOVERY_ABSTRACT_EXAMPLE]
    user_text = "\n\n".join(parts)
    return [
        ChatMessage(role="system", content=_SYSTEM_PLANNING),
        _make_user_message(user_text, ctx.images),
    ]


def build_and_recovery_prompt(
    node: Node, children: Sequence[Node], ctx: PlanningContext
) -> Sequence[ChatMessage]:
    """Build the AND-node recovery messages."""
    return _build_recovery_prompt(_AND_RECOVERY_BODY, node, children, ctx)


def build_or_recovery_prompt(
    node: Node, children: Sequence[Node], ctx: PlanningContext
) -> Sequence[ChatMessage]:
    """Build the OR-node recovery messages."""
    return _build_recovery_prompt(_OR_RECOVERY_BODY, node, children, ctx)


def build_prune_prompt(node: Node, ctx: PlanningContext) -> Sequence[ChatMessage]:
    """Build the PROMPT_PRUNE messages."""
    if ctx.insights is None:
        raise ValueError("ctx.insights must be set before calling build_prune_prompt")
    system_text = _SYSTEM_PRUNE_TEMPLATE.format(action_prompt=ctx.action_set)

    user_text = (
        f"OVERALL GOAL OF THE TASK:\n{ctx.goal}\n\n"
        f"CURRENT NODE ID:\n{node.id}\n\n"
        f"TASK CONSTRAINTS:\n{ctx.insights.constraints}\n\n"
        f"TASK PROGRESS SUMMARY:\n{ctx.insights.progress}\n\n"
        f"NEXT STEP SUGGESTION:\n{ctx.insights.suggestion}\n\n"
        f"OBSERVATION:\n{ctx.observation}\n\n"
        f"GLOBAL TREE INFORMATION:\n{ctx.tree_view}"
    )
    return [
        ChatMessage(role="system", content=system_text),
        _make_user_message(user_text, ctx.images),
    ]
