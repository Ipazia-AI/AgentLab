"""OpenRouter ``PlannerLLM`` implementation.

Implements the ``PlannerLLM`` protocol against OpenRouter's OpenAI-compatible
API using the official ``openai`` SDK.  OpenRouter accepts a custom
``base_url`` alongside a standard API key, so no extra HTTP wiring is needed.

Usage::

    from telos import OpenRouterPlanner

    planner = OpenRouterPlanner(
        api_key=os.environ["OPENROUTER_API_KEY"],
        model="meta-llama/llama-3.3-70b-instruct:free",
    )
    session = Telos(planner_llm=planner, ...)

Supported content types
-----------------------
- Plain-text ``ChatMessage`` (``content: str``) — passed directly.
- Multimodal ``ChatMessage`` (``content: list[str | Image]``) — text parts are
  wrapped as ``{"type": "text", ...}``; ``Image`` parts are base64-encoded and
  sent as OpenAI vision ``image_url`` blocks.
"""

from __future__ import annotations

import base64
from collections.abc import Sequence
from typing import Any, cast

from openai import OpenAI

from telos.core.interfaces import ChatMessage, Image

_BASE_URL = "https://openrouter.ai/api/v1"


def _content_to_api(content: str | list[str | Image]) -> str | list[dict[str, object]]:
    """Convert a ``ChatMessage.content`` value to the OpenAI message format."""
    if isinstance(content, str):
        return content
    parts: list[dict[str, object]] = []
    for item in content:
        if isinstance(item, str):
            parts.append({"type": "text", "text": item})
        else:
            b64 = base64.b64encode(item.data).decode()
            url = f"data:{item.media_type};base64,{b64}"
            parts.append({"type": "image_url", "image_url": {"url": url}})
    return parts


class OpenRouterPlanner:
    """``PlannerLLM`` backed by the OpenAI SDK pointed at OpenRouter.

    Args:
        api_key: OpenRouter API key (``OPENROUTER_API_KEY``).
        model:   Model slug as listed on openrouter.ai (e.g.
                 ``"meta-llama/llama-3.3-70b-instruct:free"``).
        timeout: Request timeout in seconds (default 60).
    """

    def __init__(self, api_key: str, model: str, *, timeout: float = 60.0) -> None:
        self._model = model
        self._client = OpenAI(api_key=api_key, base_url=_BASE_URL, timeout=timeout)

    def complete(self, messages: Sequence[ChatMessage]) -> str:
        """Send *messages* to OpenRouter and return the assistant reply text."""
        payload = [{"role": msg.role, "content": _content_to_api(msg.content)} for msg in messages]
        response = self._client.chat.completions.create(
            model=self._model,
            messages=cast(Any, payload),
        )
        if not response.choices:
            raise RuntimeError(
                f"OpenRouter returned no choices for model {self._model!r}. "
                "The model may be unavailable or rate-limited."
            )
        return response.choices[0].message.content or ""
